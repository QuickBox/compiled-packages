from setuptools import setup
import platform

setup(
    name='libtorrent',
    version='2.0.11',
    author='Arvid Norberg',
    author_email='arvid@libtorrent.org',
    description='Python bindings for libtorrent-rasterbar',
    long_description='Python bindings for libtorrent-rasterbar',
    url='http://libtorrent.org',
    platforms=[platform.system() + '-' + platform.machine()],
    license='BSD',
    package_dir = {'': '/opt/qb-compile/builds/libtorrent/build/bindings/python'}
)
