## [Transmission 2.92](https://trac.transmissionbt.com/query?milestone=2.92&group=component&order=severity) (2016-03-06)
### Mac Client
 * Build OSX.KeRanger.A ransomware removal into the app
