#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "LibtorrentRasterbar::torrent-rasterbar" for configuration "Release"
set_property(TARGET LibtorrentRasterbar::torrent-rasterbar APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(LibtorrentRasterbar::torrent-rasterbar PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libtorrent-rasterbar.so.2.1.0"
  IMPORTED_SONAME_RELEASE "libtorrent-rasterbar.so.2.1"
  )

list(APPEND _cmake_import_check_targets LibtorrentRasterbar::torrent-rasterbar )
list(APPEND _cmake_import_check_files_for_LibtorrentRasterbar::torrent-rasterbar "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libtorrent-rasterbar.so.2.1.0" )

# Import target "LibtorrentRasterbar::LibDataChannelStatic" for configuration "Release"
set_property(TARGET LibtorrentRasterbar::LibDataChannelStatic APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(LibtorrentRasterbar::LibDataChannelStatic PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libdatachannel-static.a"
  )

list(APPEND _cmake_import_check_targets LibtorrentRasterbar::LibDataChannelStatic )
list(APPEND _cmake_import_check_files_for_LibtorrentRasterbar::LibDataChannelStatic "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libdatachannel-static.a" )

# Import target "LibtorrentRasterbar::LibJuiceStatic" for configuration "Release"
set_property(TARGET LibtorrentRasterbar::LibJuiceStatic APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(LibtorrentRasterbar::LibJuiceStatic PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "C"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libjuice-static.a"
  )

list(APPEND _cmake_import_check_targets LibtorrentRasterbar::LibJuiceStatic )
list(APPEND _cmake_import_check_files_for_LibtorrentRasterbar::LibJuiceStatic "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libjuice-static.a" )

# Import target "LibtorrentRasterbar::usrsctp" for configuration "Release"
set_property(TARGET LibtorrentRasterbar::usrsctp APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(LibtorrentRasterbar::usrsctp PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "C"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libusrsctp.a"
  )

list(APPEND _cmake_import_check_targets LibtorrentRasterbar::usrsctp )
list(APPEND _cmake_import_check_files_for_LibtorrentRasterbar::usrsctp "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libusrsctp.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
