#ifndef LIBTORRENT_DIRECTORY_EVENTS_H
#define LIBTORRENT_DIRECTORY_EVENTS_H

#include <functional>
#include <string>
#include <vector>
#include <torrent/system/event.h>

namespace torrent {

struct watch_descriptor {
  using slot_string = std::function<void(const std::string&)>;

  int         descriptor;
  int         flags;
  std::string canonical_path;
  std::string path;
  slot_string slot;
};

class LIBTORRENT_EXPORT directory_events : public system::Event {
public:
  static constexpr int flag_on_added   = 0x1;
  static constexpr int flag_on_removed = 0x2;
  static constexpr int flag_on_updated = 0x3;
  static constexpr int flag_on_ready   = 0x4;

  const char*         type_name() const override { return "directory_events"; }

  bool                open();
  void                close();

  void                notify_on(const std::string& path, int flags, const watch_descriptor::slot_string& slot);

  void                event_read() override;
  void                event_write() override;
  void                event_error() override;

private:
  std::vector<watch_descriptor> m_wd_list;
};

} // namespace torrent

#endif
