## [Transmission 2.73](https://trac.transmissionbt.com/query?milestone=2.73&group=component&order=severity) (2012-10-08)
### Mac
 * Fix crash on non-English localizations
